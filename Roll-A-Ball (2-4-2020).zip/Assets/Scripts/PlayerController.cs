﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        float vertical = Input.GetAxis( "Vertical" );
        float horizontal = Input.GetAxis( "Horizontal" );

        Vector3 force = new Vector3( horizontal, 0.0f, vertical );

        rb.AddForce( force );
    }
}
